/**
 * [ABSTRACT] An abstract class to hold attributes of a staff member at UP
 * @author Jason Yao
 * @version 08/04/14
 */
public abstract class Staff extends UPPersonnel
{
    // Instance Variables
    private int salary;
    
    /**
     * [CONSTRUCTOR] Initializes the salary, name and ID number attibute for any UP staff members
     * @param initName The name of the staff member
     * @param initIDNum The ID number of the staff member
     * @param initSalary The annual salary the staff member gets
     */
    public Staff (String initName, int initIDNum, int initSalary)
    {
        // Initializes the name attribute to initName via super
        // Initializs the ID number attribute to initIDNum via super
        super(initName, initIDNum);
        
        // Initializes the salary attribute to initSalary
        salary = 0;
    }

    /**
     * [ACCESSOR] Gets the salary of the staff member
     * @return staffSalary Annual salary amount of the staff member, in pennies
     */
    abstract public int getSalary ();

    /**
     * [ACCESSOR] Outputs an object into a string format that includes the staff member's name, ID number and salary
     * @return outPutString the object in a String output
     */
    public String toString ()
    {
        // Dummy Variables
        String outputString = "";
        return outputString;
    }

    /**
     * [ACCESSOR] Returns true if the staff member's salary is equal to another's
     * @param staffComparedTo Staff object being compared to
     * @return equalTrue set to true if the salary is equal to another staff object
     */
    public boolean equals(Object staffComparedTo)
    {
        // Dummy Variables
        boolean equalTrue = true;
        return equalTrue;
    }
}

