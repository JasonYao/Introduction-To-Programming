/**
 * Creates a UP Personnel object that has a name and an ID number associated with that object
 * @author Jason Yao
 * @version 08/04/14
 */
public class UPPersonnel
{
    // Instance Variables
    private String name;
    private int idNum;
    
    /**
     * [CONSTRUCTOR] Initializes a UPPersonnel object with their ID number and name
     * @param initName
     * @param initIDNum
     */
    public UPPersonnel (String initName, int initIDNum)
    {
        // Initializes name to initName
        
        // Initializes idNum to initIDNum
        
    }
    
    /**
     * [ACCESSOR] Gets the name of the personnel
     * @return name the name of the personnel
     */
    public String getName ()
    {
        // Dummy return variable
        return "";
    }
    
    /**
     * [ACCESSOR] Gets the ID number of the personnel
     * @return idNum the ID number of the personnel
     */
    public int getIDNum ()
    {
        // Dummy return variable
        return 0;
    }
    
    /**
     * Overrides the toString method to represent the object based upon the person's name and ID number
     * @return The string representation of the object
     */
    public String toString ()
    {
        // Dummy return variable
        return "";
    }
    
    /**
     * Overrides the equals method to equate a personnel if their names are the same
     * @param personnelComparedTo the other UP Personnel object
     * @return equalsboolean returns true if the objects names are equal
     */
    public boolean equals (Object personnelComparedTo)
    {
        // Dummy return variable
        return true;
    }
}

