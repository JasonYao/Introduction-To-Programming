/**
 * Creates an array of UP Personnel objects, then calculates awards based upon certain criteria
 * @author Jason Yao
 * @version 08/04/14
 */
public class IdentifyUPPersonnelAwards
{
    /**
     * Will create an array of UP personnel objects, go through those objects,
     * and identify which of them qualify for a series of awards based upon achievement
     */
    public static void main ( String[] args )
    {
        // Logic to create an array of UPPersonnel, with undergraduate, graduate, support and faculty objects
        
        // Logic to iterate through those objects, and award a CS award to the highest GPA CS undergraduate student
        
        // Logic to iterate through those objects, and award a CS award to the highest GPA CS graduate student
        
        // Logic to iterate through those objects, and award a faculty award to the highest ranking faculty member
        
    }
}

