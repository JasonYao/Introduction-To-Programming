/**
 * [ABSTRACT] An abstract class to allow other classes to extend from it, specifically to create Student objects
 * @author Jason Yao
 * @version 08/04/14
 */
public abstract class Student extends UPPersonnel
{
    // Instance Variables
    private boolean fullTimeStatus;
    private double studentGPA;
    private int yearsEnrolled;
    private String degreeField;
    private double minStudentGPA;
    private int numCredits;
    
    /**
     * [CONSTRUCTOR] Initializes a student's values to include their status, their GPA, student year (1st, 2nd, etc),
     * their degree field, and the minimum
     * @param initName The name of the student
     * @param initIDNum The ID number of the student
     * @param initStatus The student's fulltime status
     * @param initGPA The student's current GPA as of the last official records
     * @param initEnrolledAge The number of years the student has attended UP or university in general
     * @param initDegree The student's field of study
     * @param initNumCredits The number of credits the student has taken so far
     */
    public Student (String initName, int initIDNum, boolean initStatus, double initGPA, int initEnrolledAge, String initDegree, int initNumCredits)
    {
        // Initializes the student's name and ID number
        super(initName, initIDNum);
        
        // Initializes the student's number of credits taken so far
        
        // Initializes the student's fulltime status
        
        // Initializes the student's GPA
        
        // Initializes the number of years the student has been enrolled for
        
        // Initializes the student's degree field
        
    }

    /**
     * [ACCESSOR] Gets the status of the student, about whether the student is attending UP fulltime or not
     * @return studentTimeStatus Returns true if the student is attending the minimum number of credits
     */
    public boolean getStatus ()
    {
        // Dummy Variables
        boolean studentTimeStatus = true;
        return studentTimeStatus;
    }

    /**
     * [ACCESSOR] Gets the GPA of the student
     * @return studentGPA Returns the GPA of the student, truncates to 2 decimal places after adding 0.005,
     * effectively rounding the value to 2 decimals
     */
    public double getGPA ()
    {
        // Dummy Variables
        double studentGPA = 0.0;
        return studentGPA;
    }
    
    /**
     * [ACCESSOR] Gets the number of credits the student has taken so far
     * @return studentNumCredits Returns the number of credits the student has taken so far, includes this semester's courses
     */
    public int getNumCredits ()
    {
        // Dummy Variables
        int studentNumCredits = 0;
        return studentNumCredits;
    }

    /**
     * [ACCESSOR] Gets the number of years the student has been enrolled at UP, or any other university
     * @return studentEnrolledAge Returns which year the student is in (1st year, 2nd year, etc)
     */
    public int getEnrolledAge ()
    {
        // Dummy Variables
        int studentEnrolledAge = 0;
        return studentEnrolledAge;
    }

    /**
     * [ACCESSOR] Gets the degree field of the student
     * @return studentDegreeField Returns the student's field of study in a String
     */
    public String getDegree ()
    {
        // Dummy Variables
        String studentDegreeField = "";
        return studentDegreeField;
    }

    /**
     * [ABSTRACT] Gets the minimum GPA of the student, differs from undergraduates to graduate students
     * @return studentMinGPA
     */
    abstract public double getMinGPA ();

    /**
     * [ACCESSOR] Gives a String representation of the object, showing a student's field of study, GPA, and fulltime status
     * @return studentObjectString Returns a String representing the object
     */
    public String toString ()
    {
        // Dummy Variables
        String studentObjectString = "";
        return studentObjectString;
    }

    /**
     * [ACCESSOR] Returns true if two Student objects are considered equals, and false if they are found different
     * @param studentComparedTo The Student object being compared to
     * @return studentEquals Returns true if two students are equal based upon whether they have the same fulltime status,
     * GPA score, with the same field of study, and the class name is the same.
     */
    public boolean equals (Object studentComparedTo)
    {
        // Dummy Variables
        boolean studentEquals = false;
        return studentEquals;
    }
}

